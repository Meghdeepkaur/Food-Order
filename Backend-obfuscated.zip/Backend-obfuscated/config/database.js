const _0x222d95 = _0x3d3a;
(function (_0x337b6d, _0x29f22e) {
  const _0x363f1d = _0x3d3a,
    _0x4eb349 = _0x337b6d();
  while (!![]) {
    try {
      const _0x559430 =
        -parseInt(_0x363f1d(0x192)) / 0x1 +
        parseInt(_0x363f1d(0x18d)) / 0x2 +
        (parseInt(_0x363f1d(0x18c)) / 0x3) *
          (parseInt(_0x363f1d(0x18e)) / 0x4) +
        parseInt(_0x363f1d(0x183)) / 0x5 +
        parseInt(_0x363f1d(0x187)) / 0x6 +
        -parseInt(_0x363f1d(0x191)) / 0x7 +
        (-parseInt(_0x363f1d(0x189)) / 0x8) *
          (parseInt(_0x363f1d(0x185)) / 0x9);
      if (_0x559430 === _0x29f22e) break;
      else _0x4eb349["push"](_0x4eb349["shift"]());
    } catch (_0x1e5ddb) {
      _0x4eb349["push"](_0x4eb349["shift"]());
    }
  }
})(_0x4321, 0xc1612);
function _0x3d3a(_0x5167f3, _0x294244) {
  const _0x432135 = _0x4321();
  return (
    (_0x3d3a = function (_0x3d3af0, _0x3bf1e5) {
      _0x3d3af0 = _0x3d3af0 - 0x183;
      let _0x13f42b = _0x432135[_0x3d3af0];
      return _0x13f42b;
    }),
    _0x3d3a(_0x5167f3, _0x294244)
  );
}
const mongoose = require("mongoose"),
  connectDatabase = () => {
    const _0x2ebca2 = _0x3d3a;
    mongoose[_0x2ebca2(0x190)](process[_0x2ebca2(0x18a)][_0x2ebca2(0x184)], {})[
      "then"
    ]((_0x100f29) => {
      const _0x545fd0 = _0x2ebca2;
      console[_0x545fd0(0x18b)](
        _0x545fd0(0x188) + _0x100f29["connection"][_0x545fd0(0x18f)]
      );
    });
  };
function _0x4321() {
  const _0x4758ef = [
    "connect",
    "2022230AVfdmv",
    "81331JolAyM",
    "6631635zjZrQj",
    "DB_LOCAL_URI",
    "126504WSCOMJ",
    "exports",
    "6524142KvGEGV",
    "MongoDB\x20Database\x20connected\x20with\x20HOST:",
    "1960nEeyRs",
    "env",
    "log",
    "4320795dyHozA",
    "1504148PnyehC",
    "4wmRYCT",
    "host",
  ];
  _0x4321 = function () {
    return _0x4758ef;
  };
  return _0x4321();
}
module[_0x222d95(0x186)] = connectDatabase;
